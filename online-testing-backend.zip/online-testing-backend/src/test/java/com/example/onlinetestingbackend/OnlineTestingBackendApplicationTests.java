package com.example.onlinetestingbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineTestingBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
